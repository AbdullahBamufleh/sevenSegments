#include "sevenSegments.h"

void segmentsDefines()
{
  for (int i = 2; i < 10; i++)
  {
    pinMode(i, OUTPUT);
  }
}

void clearSeg()
{
  for (int i = 2; i < 10; i++)
  {
    digitalWrite(i, LOW);
  }
}

void printSeg(int segmentNumber)
{
  switch (segmentNumber)
  {
  case 0:
    print0();
    break;
  case 1:
    print1();
    break;
  case 2:
    print2();
    break;
  case 3:
    print3();
    break;
  case 4:
    print4();
    break;
  case 5:
    print5();
    break;
  case 6:
    print6();
    break;
  case 7:
    print7();
    break;
  case 8:
    print8();
    break;
  case 9:
    print9();
    break;
  case 10:
    print10();
    break;
  }
}

void print0()
{
  clearSeg();
  for (int i = 2; i < 10; i++)
  {
    if (i == 8 || i == 5)
    {
      continue;
    }
    digitalWrite(i, HIGH);
  }
}

void print1()
{
  clearSeg();
  digitalWrite(6, HIGH);
  digitalWrite(9, HIGH);
}

void print2()
{
  clearSeg();
  for (int i = 2; i < 10; i++)
  {
    if (i == 8 || i == 9 || i == 4)
    {
      continue;
    }
    digitalWrite(i, HIGH);
  }
}

void print3()
{
  clearSeg();
  for (int i = 2; i < 10; i++)
  {
    if (i == 8 || i == 3 || i == 4)
    {
      continue;
    }
    digitalWrite(i, HIGH);
  }
}

void print4()
{
  clearSeg();
  for (int i = 2; i < 10; i++)
  {
    if (i == 8 || i == 2 || i == 3 || i == 7)
    {
      continue;
    }
    digitalWrite(i, HIGH);
  }
}

void print5()
{
  clearSeg();
  for (int i = 2; i < 10; i++)
  {
    if (i == 8 || i == 3 || i == 6)
    {
      continue;
    }
    digitalWrite(i, HIGH);
  }
}

void print6()
{
  clearSeg();
  for (int i = 2; i < 10; i++)
  {
    if (i == 8 || i == 6)
    {
      continue;
    }
    digitalWrite(i, HIGH);
  }
}

void print7()
{
  clearSeg();
  digitalWrite(6, HIGH);
  digitalWrite(7, HIGH);
  digitalWrite(9, HIGH);
}

void print8()
{
  clearSeg();
  for (int i = 2; i < 10; i++)
  {
    if (i == 8)
    {
      continue;
    }
    digitalWrite(i, HIGH);
  }
}

void print9()
{
  clearSeg();
  for (int i = 2; i < 10; i++)
  {
    if (i == 8 || i == 3)
    {
      continue;
    }
    digitalWrite(i, HIGH);
  }
}

void print10()
{
  digitalWrite(8, HIGH);
}