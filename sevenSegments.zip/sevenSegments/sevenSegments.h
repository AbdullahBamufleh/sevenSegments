#ifndef SEVENSEGMENT_H
#define SEVENSEGMENT_H
#include <Arduino.h>
void segmentsDefines();
void printSeg(int segmentNumber);
void clearSeg();
void print0();
void print1();
void print2();
void print3();
void print4();
void print5();
void print6();
void print7();
void print8();
void print9();
void print10();

#endif